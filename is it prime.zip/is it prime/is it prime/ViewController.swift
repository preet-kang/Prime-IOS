//
//  ViewController.swift
//  is it prime
//
//  Created by Amy kang on 2017-07-09.
//  Copyright © 2017 Amy kang. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var userNumber: UITextField!
    
    
    @IBAction func IsPrime(_ sender: Any) {
   
     // Check user Input
        
        if let userEnterdString = userNumber.text {
            
            let userEnterdInteger = Int(userEnterdString)
            
            if let number = userEnterdInteger {
                
                var isPrime = true // assumption
                
                var i = 2
                
                while i < number {
                    
                    if number % i == 0 {    // condition to check number
                        
                        isPrime = false
                    }
                    
                    
                    
                    i += 1   // add one to next number
                }
                
                // check result
                
                if isPrime {
                    lblResult.text = "\(number) is Prime "
                }
                else {
                    lblResult.text = "\(number) is not Prime "
                }
                
                
            }
                
            else {
                lblResult.text = "Please enter positive whole number"
            }
            
            
        }
        
        
        
    }
    
    @IBOutlet weak var lblResult: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

