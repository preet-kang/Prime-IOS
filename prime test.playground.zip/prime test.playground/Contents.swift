//: Playground - noun: a place where people can play

import UIKit

let number = 500 // enter number

var isPrime = true // assumption

var i = 2

while i < number {
    
    if number % i == 0 {    // condition to check number
        
        isPrime = false
    }
    
    
    
    i += 1   // add one to next number
}

print(isPrime) 